//
//  SwiftJson.swift
//  SwiftJson
//
//  Created by jabeed on 05/11/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import Foundation
struct JsonModel{
    var artistName: String
    var trackCensoredName: String
    var artworkUrl100: String
    
    init(json:JSON){
        artistName = json["artistName"].stringValue
        trackCensoredName = json["trackCensoredName"].stringValue
        artworkUrl100 = json["artworkUrl100"].stringValue
    }
}
